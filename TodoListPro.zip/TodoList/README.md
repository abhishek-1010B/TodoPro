# Todo List

A simple Todo List with an internal collection array of Todos. We can add, modify, and retrieve Todos.
