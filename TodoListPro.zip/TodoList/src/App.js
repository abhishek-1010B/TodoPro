import React, { useEffect, useState } from "react";
import { VoyageProvider, Wallet, getLogicDriver } from "js-moi-sdk";
import { info, success } from "./utils/toastWrapper";
import { Toaster } from "react-hot-toast";
import Loader from "./components/Loader";

// ------- Update with your credentials ------------------ //
const logicId =
  "0x08000018bc4ebcff8a0eac1db4ccfb4386554e9b061e03ca9eeff8ac46b35afa8169b1";
const mnemonic =
  "wealth nation hub warfare rare lonely mother cloth burger indoor shuffle crack";

async function gettingLogicDriver(logicId, mnemonic, accountPath) {
  const provider = new VoyageProvider("babylon");
  const wallet = new Wallet(provider);
  await wallet.fromMnemonic(mnemonic, accountPath);
  return await getLogicDriver(logicId, wallet);
}

function App() {
  const [todoName, setTodoName] = useState("");
  const [todos, setTodos] = useState([]);
 const [showCompleted, setShowCompleted] = useState(false);
  const [logicDriver, setLogicDriver] = useState(null);

  // Loaders
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [marking, setMarking] = useState(false);

  useEffect(() => {
    async function initializeLogicDriver() {
      try {
        const driver = await gettingLogicDriver(
          logicId,
          mnemonic,
          "m/44'/6174'/7020'/0/0"
        );
        setLogicDriver(driver);
        await getTodos();
      } catch (error) {
        console.error(error);
      }
    }

    initializeLogicDriver();
  }, []);

  const handleTodoName = (e) => {
    setTodoName(e.currentTarget.value);
  };

  const getTodos = async () => {
    try {
      const tTodos = await logicDriver.persistentState.get("todos");
      setTodos(tTodos);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error(error);
    }
  };

  const add = async (e) => {
    e.preventDefault();
    try {
      setAdding(true);
      info("Adding Todo ...");

      const ix = await logicDriver.routines.Add([todoName]).send({
        fuelPrice: 1,
        fuelLimit: 1000,
      });

      // Waiting for tesseract to be mined
      await ix.wait();

      await getTodos();
      success("Successfully Added");
      setTodoName("");
      setAdding(false);
    } catch (error) {
      console.log(error);
    }
  };

  const markCompleted = async (id) => {
    try {
      setMarking(id);
      const ix = await logicDriver.routines.MarkTodoCompleted([id]).send({
        fuelPrice: 1,
        fuelLimit: 1000,
      });
      // Waiting for tesseract to be mined
      await ix.wait();

      const tTodos = [...todos];
      tTodos[id].completed = true;
      setTodos(tTodos);
      setMarking(false);
    } catch (error) {
      console.log(error);
    }
  };

  const deleteTodo = async (id) => {
    try {
      const updatedTodos = todos.filter((todo, index) => index !== id);
      setTodos(updatedTodos);
    } catch (error) {
      console.log(error);
    }
  };

  //Kindly add new things to test the code.
  return (
    <>
      <Toaster />
      <section className="section-center">
        <form className="todo-form">
          <p className="alert"></p>
          <h3>Todo buddy Pro</h3>
          <div className="form-control">
            <input
              value={todoName}
              name="todoName"
              onChange={handleTodoName}
              type="text"
              id="todo"
              placeholder="e.g. Attend Moi Event"
            />
            <button onClick={add} type="submit" className="submit-btn">
              {adding ? <Loader color={"#002"} loading={adding} /> : "Add Todo"}
            </button>
          </div>
        </form>
        {!loading ? (
          <div className="todo-container show-container">
            {todos.map((todo, index) => (
              <div className="todo-list" key={index}>
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => markCompleted(index)}
                />
                {todo.name}
                {todo.completed && (
                  <button
                    onClick={() => deleteTodo(index)}
                    className="delete-btn"
                  >
                    Delete
                  </button>
                )}
              </div>
            ))}
            <label>
              Show Completed
              <input
                type="checkbox"
                checked={showCompleted}
                onChange={() => setShowCompleted(!showCompleted)}
              />
            </label>
          </div>
        ) : (
          <div style={{ marginTop: "20px" }}>
            <Loader color={"#000"} loading={loading} />
          </div>
        )}
      </section>
    </>
  );
}

export default App;
